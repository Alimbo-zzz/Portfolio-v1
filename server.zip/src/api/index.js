import GET_all from './GET_all.js';


export {
	GET_all,

};