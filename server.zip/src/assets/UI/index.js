import SVG from './SVG';


export {
	SVG,
}