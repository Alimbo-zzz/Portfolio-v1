import React from 'react';

// import {Modal} from '@contexts';





const ContextWrap = ({children}) => {
	
	return (<>
		{children}
	</>);
}

export default ContextWrap;