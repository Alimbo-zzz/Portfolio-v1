export default () => {
	
	const creteId = () => Math.random().toString(36).slice(-6);
	
	

	return creteId()

};