import Landing from './Landing';
import Admin from './Admin';
import Error from './Error';


export{
	Landing,
	Admin, 
	Error,
}