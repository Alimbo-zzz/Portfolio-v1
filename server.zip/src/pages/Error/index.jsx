import React from 'react';
import scss from './style.module.scss';

const Error = (events) => {
	const {} = events;
	
	return (<>
		<h1>404 <br /> page not found</h1>
	</>);
}

export default Error;